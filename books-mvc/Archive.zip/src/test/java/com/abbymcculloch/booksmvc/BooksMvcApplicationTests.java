package com.abbymcculloch.booksmvc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BooksMvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
