package com.abbymcculloch.daikichicore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DaikichiCoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
