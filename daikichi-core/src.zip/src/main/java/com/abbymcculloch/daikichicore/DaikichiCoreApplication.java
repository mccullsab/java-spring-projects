package com.abbymcculloch.daikichicore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DaikichiCoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(DaikichiCoreApplication.class, args);
	}

}
