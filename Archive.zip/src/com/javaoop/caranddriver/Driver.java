package com.javaoop.caranddriver;

class Driver extends Car {
	
	public Driver() {
		super();
	}

	public void driving() {
        System.out.println("Drive Selected");
        this.gasLevel --;
        System.out.println("Gas Level: " + this.gasLevel);	
	}
	public void boosting() {
        System.out.println("Booster Selected");	
        this.gasLevel -= 3;
        System.out.println("Gas Level: " + this.gasLevel);	
        
	}
	public void refuel() {
        System.out.println("Refuel Selected");
        this.gasLevel += 2;
        System.out.println("Gas Level: " + this.gasLevel);	
	}

}
