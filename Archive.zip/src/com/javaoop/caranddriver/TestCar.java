package com.javaoop.caranddriver;

public class TestCar {

	public static void main(String[] args) {
		Driver d = new Driver();
		d.driving();
		d.driving();
		d.driving();
		d.boosting();
		d.refuel();
	}

}
