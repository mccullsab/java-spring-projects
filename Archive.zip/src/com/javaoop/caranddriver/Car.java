package com.javaoop.caranddriver;

public class Car {
	protected int gasLevel;
	
	public Car() {
		gasLevel = 10;
	}
	
	public int getGasLevel() {
		return gasLevel;
	}

	public void setGasLevel(int gasLevel) {
		this.gasLevel = gasLevel;
	}

	public void display() {
        System.out.println("Gas Level: " + this.gasLevel);
	}

}
