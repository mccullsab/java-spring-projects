package com.abbymcculloch.blackbelt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlackBeltExamJavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
