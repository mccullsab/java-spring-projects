package com.abbymcculloch.blackbelt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BlackBeltExamJavaApplication {

	public static void main(String[] args) {
		SpringApplication.run(BlackBeltExamJavaApplication.class, args);
	}

}
