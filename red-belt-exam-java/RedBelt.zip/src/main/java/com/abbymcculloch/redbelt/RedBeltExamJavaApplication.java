package com.abbymcculloch.redbelt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RedBeltExamJavaApplication {

	public static void main(String[] args) {
		SpringApplication.run(RedBeltExamJavaApplication.class, args);
	}

}
